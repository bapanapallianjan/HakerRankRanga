package com.hackerrank.examQuestions;

public class RobotClass {
	public static void main(String[] args) {
		int x = 2;
		int y = 1;
		int dx = 1;
		int dy = 1;
		
		Robot firstRobot = new Robot();
		firstRobot.printCurrentCoordinates();
		
		Robot secondRobot = new Robot(x, y);
		secondRobot.printCurrentCoordinates();
		
		for(int i=1; i<3; i++) {
			secondRobot.moveX(dx); 
			secondRobot.printLastMove();
			secondRobot.printCurrentCoordinates();
			secondRobot.moveY(dy);
			secondRobot.printLastCoordinates();
			
			dx += i*i;
			dy -= i*i;
		} //for
			
	}//main
} //RobotClass

class Robot{
	private int x, y ,dx, dy;
	public Robot(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public Robot() {
		this.x = 0;
		this.y = 5;
		//System.out.println(this.x+" "+this.y);
	}
	public void printCurrentCoordinates() {
		System.out.println(this.x+" "+this.y);
	}
	public void moveX(int dx) {
		this.x = this.x + dx;
		this.dx = dx;
	}
	public void printLastMove() {
		System.out.println("x "+dx);
	}
	public void printLastCoordinates() {
		System.out.println(this.x+" "+this.dy);
	}
	public void moveY(int dy) {
		this.dy = this.y;
		this.y = this.y + dy;
	}
	
} //Robot Class
