package com.hackerrank.algorithms;

public class FloorSum {
	public static void main(String[] args) {
		double GB_num1 = 5.5;//GB_scan.nextFloat();
		double GB_num2 = 2.2;//GB_scan.nextFloat();
		
		double sum = GB_num1+GB_num2;
		
		System.out.println((int)(Math.floor(sum)));
	}
}
